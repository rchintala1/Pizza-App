//
//  AppDelegate.h
//  TopPizzasTestCase
//
//  Created by ramesh Chandra on 5/30/16.
//  Copyright © 2016 ramesh Chandra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

