//
//  ViewController.h
//  TopPizzasTestCase
//
//  Created by ramesh Chandra on 5/30/16.
//  Copyright © 2016 ramesh Chandra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property (strong, nonatomic) IBOutlet UITableView *myTableView;

@end

