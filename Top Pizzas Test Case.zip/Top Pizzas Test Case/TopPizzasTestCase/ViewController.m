//
//  ViewController.m
//  TopPizzasTestCase
//
//  Created by ramesh Chandra on 5/30/16.
//  Copyright © 2016 ramesh Chandra. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic,strong) NSArray *jsonDataArray;
@property (nonatomic,strong) NSMutableArray *pizzanamesArray;
@property (nonatomic,strong) NSMutableArray *orderdJsonArray;
@property (nonatomic,strong) NSArray *topitems;




@end

@implementation ViewController
@synthesize jsonDataArray;
@synthesize pizzanamesArray;
@synthesize orderdJsonArray;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = NSLocalizedString(@"Best Pizza Combinations", @"Best Pizza Combinations");
    
    //allocations
    pizzanamesArray = [[NSMutableArray alloc] init];
    orderdJsonArray = [[NSMutableArray alloc] init];
    
    //parsing json file and sorting data
    [self parseJson];
    
    self.myTableView.delegate = self;
    self.myTableView.dataSource = self;
    [self.myTableView reloadData];
    
}

//Method to format topping details before adding to table cell
-(NSString*)formatToppings:(NSString *)strIn{
    NSError *error = nil;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^a-z ,]" options:NSRegularExpressionCaseInsensitive error:&error];
    NSString *modifiedString = [regex stringByReplacingMatchesInString:strIn options:0 range:NSMakeRange(0, [strIn length]) withTemplate:@""];
    return modifiedString;
}

-(void)parseJson{
    
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"pizzas" ofType:@"json"];
    NSString *myJSON = [[NSString alloc] initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:NULL];
    NSError *error =  nil;
    jsonDataArray = [NSJSONSerialization JSONObjectWithData:[myJSON dataUsingEncoding:NSUTF8StringEncoding] options:kNilOptions error:&error];
    
    NSMutableArray *mutableArray = [[NSMutableArray alloc] init];
    
    [jsonDataArray enumerateObjectsUsingBlock:^(NSDictionary *item , NSUInteger idx, BOOL *stop) {
        [mutableArray addObject:item[@"toppings"]];
        NSError * err;
        NSData * jsonCombination = [NSJSONSerialization  dataWithJSONObject:item[@"toppings"] options:0 error:&err];
        NSString * strCombination = [[NSString alloc] initWithData:jsonCombination encoding:NSUTF8StringEncoding];
        [pizzanamesArray addObject:strCombination];
    }];
    
    
    
#pragma finding repeted items count
    
    NSCountedSet *countedSet = [[NSCountedSet alloc] initWithArray:[pizzanamesArray mutableCopy]];
    
    for (NSString *item in countedSet) {
        
        int count = (int)[countedSet countForObject: item];
        
        //preparing dictionary with item and its count
        
        NSMutableDictionary *dictionary = [[NSMutableDictionary alloc] init];
        [dictionary setObject:item forKey:@"topping_name"];
        [dictionary setObject:[NSNumber numberWithInt:count] forKey:@"number_of_times"];
        
        [orderdJsonArray addObject:dictionary];
    }
    
#pragma sorting array to find top orderd pizzas
    
    NSSortDescriptor *sortByName = [NSSortDescriptor sortDescriptorWithKey:@"number_of_times" ascending:NO];
    NSArray *sortDescriptors = [NSArray arrayWithObject:sortByName];
    NSArray *sortedArray = [orderdJsonArray sortedArrayUsingDescriptors:sortDescriptors];
    
    [orderdJsonArray removeAllObjects];
    orderdJsonArray = [sortedArray copy];
    
    
}

#pragma mark UITableView Delegate and dataSource methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    
    
    _topitems= [self.orderdJsonArray subarrayWithRange: NSMakeRange( 0, 20 )];
    
    return _topitems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"MyIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:MyIdentifier];
    }
    
    
    NSDictionary *dict = [self.topitems objectAtIndex:indexPath.row];
    
    
    
    cell.textLabel.text = [self formatToppings:[dict valueForKey:@"topping_name"]];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"number_of_times"]];
    
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return NSLocalizedString(@"Top_20_Pizza Combinations", @"Top_20_Pizza Combinations");
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 20.0f;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
